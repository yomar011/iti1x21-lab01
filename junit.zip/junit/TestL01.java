public class TestL01 {

   public static void main(String[] args) {


        TestUtils.runClass(TestL1Q3_ArrayInsertionDemo.class);
        TestUtils.runClass(TestL1Q3_AverageDemo.class);
        TestUtils.runClass(TestL1Q3_SquareArray.class);
        TestUtils.runClass(TestL1Q3_ReverseSortDemo.class);
        TestUtils.runClass(TestL1Q5.class);
        TestUtils.runClass(TestL1Q6.class);

    }

}
